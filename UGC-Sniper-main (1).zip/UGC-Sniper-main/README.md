
# [UGC Sniper]((https://discord.gg/3Uvcf8d9aY))
A free UGC sniper bot for roblox that sniper free limiteds.

**[Unofficial installation guide](https://docs.google.com/document/d/1VAqSW067-8OlexScBwje-HJcMn7vXJJM3WuRHE97-QU/edit)**

## Table of contents
1. [Table of contents](https://github.com/J3ldo/UGC-Sniper#Table-of-contents)
2. [Premium](https://github.com/J3ldo/UGC-Sniper#Premium)
3. [Features](https://github.com/J3ldo/UGC-Sniper#features)
4. [How to use](https://github.com/J3ldo/UGC-Sniper#how-to-use)

## [Premium](https://discord.gg/3Uvcf8d9aY)
If you aren't happy with the preformance of this UGC Sniper or want a limited sniper. You can buy the premium limited sniper. This sniper has way more functionality because for just €10,- you can get the following features.
  
Check prices way faster, and faster proxies.
Search items based on RAP, Projection detection, alt account support, buying every limited with a price under 50 robux, blacklisted keywords, checking 119 limiteds in 0,75 seconds (no proxies), dynamic pricing of limited, and way more. 

## Features
* Buying the free limited
* Searching 24/7 to see if its on sale
* Easy to use
* Lightweight
* Rebuys when failed buying

## How to use

### Step 1
Install python. You first need to install python you can do this [here](https://www.python.org/download). After downloading python you need to install the requests library. You can do this by typing "pip install requests" in the command prompt or if that doesnt work "python -m pip install requests". 

### Step 2
Click on code > download zip. This will download the program as a .zip file after that unpack the installed limited sniper into a directory of choice.
 
### Step 3
You need to put in your roblox cookie into the cookie.txt file.

First install this repository: https://github.com/J3ldo/Roblox-Token-Fetcher  
Then open google chrome and click on the extensions button > manage extensions > load unpacked  
Select the repository directory and click on the extension icon now just copy the .ROBLOSECURITY this is the 1st one!  
And your done!

### Step 4
Put in the desired limiteds in limiteds.txt and seperate them with a comma.
It should look like this
Asset1, Asset2, Asset3

### Step 5
Just run the main.py file and you will see it starting to check if its free.
That's all, hope you get some good deals and some good robux, if you do make sure to star this repository.
